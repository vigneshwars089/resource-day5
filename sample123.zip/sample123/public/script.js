var app=angular.module('App', ['ngMaterial','ngAnimate','angular-venn','ngMessages',"chart.js"]);
// var app1=angular.module('main'['ui.router'])
// app1.config(function($stateProvider,$urlRouterProvider) {
//
//
//
//
//     $urlRouterProvider.otherwise('/login');
//
//     $stateProvider
//         .state('login', {
//             url: '/login',
//             templateUrl: '../views/login.html'
//           })
//          .state('home.RFP', {
//            url: '/RFP',
//             templateUrl: '../views/landing.html'
//           })
//         .state('home.DI', {
//           url: '/DI',
//            templateUrl: '../views/DI.html'
//          })
//         .state('home.Demo', {
//          url: '/Demo',
//           templateUrl: '../views/Demo.html'
//           })
//         .state('home.Prototype', {
//           url: '/Prototype',
//           templateUrl: '../views/Prototype.html'
//           })
//         .state('home.RequirementGathering', {
//           url: '/RequirementGathering',
//           templateUrl: '../views/RequirementGathering.html'
//           })
//         .state('home.CostShared', {
//           url: '/CostShared',
//           templateUrl: '../views/CostShared.html'
//         })
//         .state('home.AllocationDone', {
//          url: '/AllocationDone',
//          templateUrl: '../views/AllocationDone.html'
//         })
//        .state('home.AllRFP', {
//         url: '/AllRFP',
//         templateUrl: '../views/Dashboard.html'
//         })
//         .state('home.AllPrototype', {
//          url: '/AllPrototype',
//          templateUrl: '../views/AllPrototype.html'
//          })
//     .state('home.InProgress', {
//      url: '/InProgress',
//      templateUrl: '../views/InProgress.html'
//    })
//    .state('home.Submitted', {
//     url: '/Submitted',
//     templateUrl: '../views/Submitted.html'
//   })
//  .state('home.Won', {
//   url: '/Won',
//   templateUrl: '../views/Won.html'
// })
// .state('home.Lost', {
//  url: '/Lost',
//  templateUrl: '../views/Lost.html'
// })
// .state('home.OnHold', {
//  url: '/OnHold',
//  templateUrl: '../views/OnHold.html'
// })
// // .state('home.OnHold', {
// //  url: '/OnHold',
// //  templateUrl: '../views/OnHold.html'
// // })
// .state('home.Developement', {
//  url: '/Developement',
//  templateUrl: '../views/PDevelopement.html'
// })
// .state('home.Accepted', {
//  url: '/Accepted',
//  templateUrl: '../views/PAccepted.html'
// })
// .state('home.Rejected', {
//  url: '/Rejected',
//  templateUrl: '../views/PRejected.html'
// })
// // .state('home.OnHold', {
// //  url: '/OnHold',
// //  templateUrl: '../views/OnHold.html'
// // })
// .state('home.createpage', {
//  url: '/createpage',
//  templateUrl: '../views/createpage.html'
// })

// });

app.controller('tabcontroller', ['$scope', function($scope) {
	$scope.changeFilter = function() {
angular.element($document[0].querySelector('#more').style.display='none');

		// document.getElementById('more').style.display='block';
		console.log("tab");
}


}]);

app.controller('demoController', function($scope) {
	console.log("SDLbnkasdkb");
	$scope.myStyle="width:'200px';background:red";
	$scope.vennData = [
		{sets: ['Head Count'], size: 70},
		{sets: ['Billable Allocation'], size: 20},
		{sets: ['SGA'], size: 10},
		{sets: ['Non-Billable Allocation'], size: 10},
		 {sets: ['Head Count','Billable Allocation'], size: 20},
		 {sets: ['Head Count','SGA'], size: 30},
		 {sets: ['Head Count','Non-Billable Allocation'], size: 20},
		//  {sets: ['Head Count','Billable Allocation', 'SGA'], size: 1},
	];
	// $scope.venn.width

});



app.controller('SearchCtrl', Autosearch);

  function Autosearch ($timeout, $q) {
    var self = this;

    // list of `state` value/display objects
    self.states        = loadAll();
    self.selectedItem  = null;
    self.searchText    = null;
    self.querySearch   = querySearch;

    // ******************************
    // Internal methods
    // ******************************

    /**
     * Search for states... use $timeout to simulate
     * remote dataservice call.
     */
    function querySearch (query) {
      var results = query ? self.states.filter( createFilterFor(query) ) : self.states;
      var deferred = $q.defer();
      $timeout(function () { deferred.resolve( results ); }, Math.random() * 1000, false);
      return deferred.promise;
    }

    /**
     * Build `states` list of key/value pairs
     */
    function loadAll() {
      var allStates = 'Alabama, Alaska, Arizona, Arkansas, California, Colorado, Connecticut, Delaware,\
              Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Kentucky, Louisiana,\
              Maine, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana,\
              Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina,\
              North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode Island, South Carolina,\
              South Dakota, Tennessee, Texas, Utah, Vermont, Virginia, Washington, West Virginia,\
              Wisconsin, Wyoming';

      return allStates.split(/, +/g).map( function (state) {
        return {
          value: state.toLowerCase(),
          display: state
        };
      });
    }

    /**
     * Create filter function for a query string
     */
    function createFilterFor(query) {
      var lowercaseQuery = angular.lowercase(query);

      return function filterFn(state) {
        return (state.value.indexOf(lowercaseQuery) === 0);
      };

    }
  }


	app.controller('lineController', ['$scope', function($scope) {
	  $scope.labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	  $scope.series = ['Requested', 'Confirmed','Allocated'];
	  $scope.data = [
	    [65, 59, 60, 81, 86, 55, 90, 78, 58, 60, 89, 76],
	    [28, 48, 40, 19, 56, 27, 30, 65, 29, 20, 41, 56],
	 [ 24, 40, 19, 56, 27, 30, 65, 19, 20, 41, 56,33]
	  ];

	  $scope.onClick = function(points, evt) {
	    console.log(points, evt);
	  };
	  $scope.datasetOverride = [{
	    yAxisID: 'y-axis-1'
	  }, {
	    yAxisID: 'y-axis-2'
	  },
	{
	    yAxisID: 'y-axis-3'
	}];
	  $scope.options = {
	    scales: {
	      yAxes: [{
	        id: 'y-axis-1',
	        type: 'linear',
	        display: true,
	        position: 'left'
	      }, {
	        id: 'y-axis-2',
	        type: 'linear',
	        display: true,
	        position: 'right'
	      }, {
	        id: 'y-axis-3',
	        type: 'linear',
	        display: false,
	        position: 'right'
	      }]
	    }
	  };

		 $scope.yearly = function() {
			//  console.log($scope.data[0][0]);

			 var yearlyData=[];
			 var m,k,j,num;
			 for (var i = 0; i < $scope.data.length; i++) {
				 var tempdata=[];
				 m=0;
				 k=0;
				 while(m <$scope.data[i].length){
					 j=0;
					num=0;
				 while(j<4)
				 {
					num+=$scope.data[i][m];
					j++;
					m++;
				 }

			tempdata[k]=num;
			 k++;
		}
		yearlyData.push(tempdata);
			 }
console.log(yearlyData);
$scope.data=yearlyData;
$scope.labels = ["Quarter 1", "Quarter 2", "Quarter 3"];
			//  for()
			// console.log($scope.data[0][0]);
			// console.log($scope.data.length);
		}
	}]);



// app.controller('mainController',function($scope,$state,$mdDialog){
//   $scope.test="hi";
//   $scope.toggler=false;
//   // $scope.main="./views/RFP.html";
//   $scope.sample=function(data){
//     if(!$scope.$$phase) {
//      $scope.$apply(function () {
//
//          $scope.main="./views/"+data+".html";
//      });
//    }else{
//         $scope.main="./views/"+data+".html";
//    }
//
//   }
//   $scope.leave=function() {
//     $state.go('home');
//   }
//
// $scope.RFP=function(data)
// {
//   $state.go('home.'+data);
// }
// $scope.Prototype=function(data)
// {
//   $state.go('home.'+data);
// }
// $scope.close=function()
// {
//   $mdDialog.hide();
// }
//
// $scope.All=function(data)
// {
//   $state.go('home.'+data);
// }
//
// $scope.create =function()
// {
//   $state.go('home.createpage');
//   $mdDialog.show({
//      controller: 'mainController',
//      templateUrl: '../views/createpage.html',
//      parent: angular.element(document.body),
//     //  targetEvent: ev,
//      clickOutsideToClose:true,
//      fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
//    })
//    .then(function(answer) {
//      $scope.status = 'You said the information was "' + answer + '".';
//    }, function() {
//      $scope.status = 'You cancelled the dialog.';
//    });
//  };
//
//   $scope.Nav=function(toggle){
//     console.log(toggle);
//     if(toggle==true){
//       document.getElementById("mySidenav").style.width = "250px";
//       document.getElementById("sideArrow").style ="margin-left:250px;";
//       document.getElementById("sideArrow").innerHTML='&#8810';
//     }else{
//       document.getElementById("mySidenav").style.width = "0";
//       document.getElementById("sideArrow").style ="margin-left:0px";
//       document.getElementById("sideArrow").innerHTML='&#8811';
//     }
//
//   }
// })
