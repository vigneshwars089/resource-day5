var app=angular.module('App', ['ngMaterial','ui.router','ngAnimate']);

app.config(function($stateProvider,$urlRouterProvider) {

    $urlRouterProvider.otherwise('/home');

    $stateProvider
        .state('home', {
            url: '/home',
            templateUrl: '../../views/home.html'
          })
  });
  app.controller('mainController',function($scope,$state,$mdDialog){
    // $scope.test="hi";
    // $scope.toggler=false;
    // $scope.main="./views/RFP.html";
    $scope.sample=function(data){
      if(!$scope.$$phase) {
       $scope.$apply(function () {

           $scope.main="./views/"+data+".html";
       });
     }else{
          $scope.main="./views/"+data+".html";
     }
   }
   $scope.sample2=function(){
     $state.go('home');
     google.charts.load('current', {'packages':['geochart']});
          google.charts.setOnLoadCallback(drawRegionsMap);

          function drawRegionsMap() {

           var data= null;
           var jsonObj = [];
             for(var k in Global_chart_data)
             {

                 jsonObj[k] = Global_chart_data[k];


             }

                  var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
              //    var data2 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);

                 var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
                  var options = {

                 colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
                  };
                  function selectHandler() {
                          var selectedItem = chart.getSelection()[0];
                          if (selectedItem) {
                            var topping = data.getValue(selectedItem.row, 1);
                            getloc=data.getValue(selectedItem.row, 0);
                            document.getElementById("myLink").innerHTML=topping;
                          }
                        }
                         google.visualization.events.addListener(chart, 'select', selectHandler);
                  chart.draw(data, options);
                 //  setInterval(function() {
                 //      chart.draw(data, options);
                 //   }, 2000);
                 //   setInterval(function() {
                 //       chart.draw(data2, options);
                 //    }, 4000);

          }

  }
});
